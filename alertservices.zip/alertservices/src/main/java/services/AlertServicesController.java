/**
 * 
 */
package services;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import client.AlertClient;
import model.Alerts;

/**
 * @author tvraghavan
 *
 */
@RestController
public class AlertServicesController {
	private static Logger logger = LoggerFactory
			.getLogger(AlertServicesController.class);

	@RequestMapping("/alert/{alertID}")
	public ResponseEntity<Alerts> getAlert(@PathVariable String alertID) {
		logger.info("getAlertDetails()-start");

		AlertServices alertServices = AlertClient.getAlertServices();
		if (alertServices != null) {
			logger.info("getAlertDetails()-end");
			return ResponseEntity.ok(alertServices.getAlert(alertID));
		}
		else {
			logger.info("getAlertDetails()-end");
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
	}
}
