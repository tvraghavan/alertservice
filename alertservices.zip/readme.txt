Invoke the alert GET service
	http://localhost:7080/alert/1

Expected output:
	Return an instance of alert object

Actual output:
	Failing to locate the alertServices bean

2017-05-04 21:49:05.323 DEBUG 17208 --- [nio-7080-exec-1] .i.s.PathMatchingResourcePatternResolver : Resolved classpath location [componentAppContext.xml] to resources []
2017-05-04 21:49:05.323 DEBUG 17208 --- [nio-7080-exec-1] o.s.b.f.xml.XmlBeanDefinitionReader      : Loaded 0 bean definitions from location pattern [classpath*:componentAppContext.xml]
2017-05-04 21:49:05.323 DEBUG 17208 --- [nio-7080-exec-1] o.s.c.s.ClassPathXmlApplicationContext   : Bean factory for org.springframework.context.support.ClassPathXmlApplicationContext@5c1cea70: org.springframework.beans.factory.support.DefaultListableBeanFactory@12d9e0: defining beans []; root of factory hierarchy
...
...
...
2017-05-04 21:49:05.328  INFO 17208 --- [nio-7080-exec-1] client.AlertClient                       : -------------------------------------
2017-05-04 21:49:05.328  INFO 17208 --- [nio-7080-exec-1] client.AlertClient                       : successfully loaded the context componentAppContext
2017-05-04 21:49:05.328  INFO 17208 --- [nio-7080-exec-1] client.AlertClient                       : -------------------------------------
2017-05-04 21:49:05.328 ERROR 17208 --- [nio-7080-exec-1] client.AlertClient                       : *******************************************
2017-05-04 21:49:05.329 ERROR 17208 --- [nio-7080-exec-1] client.AlertClient                       : Unable to load the bean(alertServices) because of:org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named 'alertServices' available
2017-05-04 21:49:05.329 ERROR 17208 --- [nio-7080-exec-1] client.AlertClient                       : *******************************************

