/**
 * 
 */
package services;

import static org.junit.Assert.*;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import client.AlertClient;

/**
 * @author tvraghavan
 *
 */

public class AlertServiceTest {
	private static Logger logger = LoggerFactory.getLogger(AlertServiceTest.class);
	@Test
	public void testGetAlert() {
		AlertServices as = AlertClient.getAlertServices();
		logger.info("alertDetails="+as.getAlert("1"));
	}

}
