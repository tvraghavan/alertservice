/**
 * 
 */
package model;

import java.util.Date;

/**
 * @author tvraghavan
 *
 */
public class Alerts {
	private String alertID;
	private String alertCategory;
	private Date alertDate;
	private String alertMessage;
	public String getAlertID() {
		return alertID;
	}
	public void setAlertID(String alertID) {
		this.alertID = alertID;
	}
	public String getAlertCategory() {
		return alertCategory;
	}
	public void setAlertCategory(String alertCategory) {
		this.alertCategory = alertCategory;
	}
	public Date getAlertDate() {
		return alertDate;
	}
	public void setAlertDate(Date alertDate) {
		this.alertDate = alertDate;
	}
	public String getAlertMessage() {
		return alertMessage;
	}
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * 
	 */
	public Alerts() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param alertID
	 * @param alertCategory
	 * @param alertDate
	 * @param alertMessage
	 */
	public Alerts(String alertID, String alertCategory, Date alertDate, String alertMessage) {
		super();
		this.alertID = alertID;
		this.alertCategory = alertCategory;
		this.alertDate = alertDate;
		this.alertMessage = alertMessage;
	}
	@Override
	public String toString() {
		return "Alerts [alertID=" + alertID + ", alertCategory=" + alertCategory + ", alertDate=" + alertDate
				+ ", alertMessage=" + alertMessage + "]";
	}
	
	
	
}
