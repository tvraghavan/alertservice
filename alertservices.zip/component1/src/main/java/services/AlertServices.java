package services;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import model.Alerts;


public class AlertServices {
	private static Logger logger = LoggerFactory.getLogger(AlertServices.class);
	public Alerts getAlert(String alertID) {
		logger.info("getAlert()-service-call");
		return new Alerts(alertID,"COMMON",new Date(),"Sample Alert-".concat(alertID));
	}
}
