/**
 * 
 */
package client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import services.AlertServices;

/**
 * @author tvraghavan
 *
 */
public class AlertClient {
	private static ClassPathXmlApplicationContext context;
	private static Logger logger = LoggerFactory.getLogger(AlertClient.class);
	static {
		try {
			context = new ClassPathXmlApplicationContext(
					"classpath*:componentAppContext.xml");
			logger.info("-------------------------------------");
			logger.info("successfully loaded the context componentAppContext");
			logger.info("-------------------------------------");
		} catch (Exception e) {
			logger.error("*******************************************");
			logger.error("Unable to load the context because of:" + e);
			logger.error("*******************************************");
		}
	}

	public static AlertServices getAlertServices() {
		try {
			if (context != null) {
				return (AlertServices) context.getBean("alertServices");
			} else {
				logger.warn("Context is null");
				return null;
			}
		} catch (Exception e) {
			logger.error("*******************************************");
			logger.error("Unable to load the bean(alertServices) because of:" + e);
			logger.error("*******************************************");
		}
		
		return null;
	}
}
